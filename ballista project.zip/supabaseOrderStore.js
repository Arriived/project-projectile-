import { createClient } from '@supabase/supabase-js';
import { config } from './config.js';

// Service role key -- this deliberately bypasses RLS. Only this
// service should ever write to bridge_orders.status; the frontend can
// insert and read its own rows but has no update policy (see the SQL
// migration).
const supabase = createClient(config.supabaseUrl, config.supabaseServiceKey);

export async function getActiveOrders() {
  const { data, error } = await supabase
    .from('bridge_orders')
    .select('*')
    .in('status', ['PENDING_ATTESTATION', 'ATTESTED'])
    .lt('claim_attempts', config.maxClaimAttempts)
    .order('created_at', { ascending: true });

  if (error) throw error;
  return data;
}

export async function markAttested(orderId, messageBytes, attestation) {
  const { error } = await supabase
    .from('bridge_orders')
    .update({
      status: 'ATTESTED',
      message_bytes: messageBytes,
      attestation,
      updated_at: new Date().toISOString(),
    })
    .eq('id', orderId)
    .eq('status', 'PENDING_ATTESTATION'); // idempotency guard

  if (error) throw error;
}

export async function markClaimSubmitted(orderId) {
  const { error } = await supabase
    .from('bridge_orders')
    .update({
      status: 'CLAIM_SUBMITTED',
      updated_at: new Date().toISOString(),
    })
    .eq('id', orderId)
    .eq('status', 'ATTESTED'); // idempotency guard -- only move forward from ATTESTED

  if (error) throw error;
}

export async function markClaimed(orderId, arcTxHash) {
  const { error } = await supabase
    .from('bridge_orders')
    .update({
      status: 'CLAIMED',
      arc_claim_tx_hash: arcTxHash,
      updated_at: new Date().toISOString(),
    })
    .eq('id', orderId);

  if (error) throw error;
}

/**
 * Records a failure and either resets the order to retry from the
 * right stage, or marks it FAILED once max attempts is hit.
 *
 * retryStatus should be 'PENDING_ATTESTATION' if the failure happened
 * before attestation was fetched, or 'ATTESTED' if attestation was
 * already fetched and only the claim submission failed -- retrying
 * from ATTESTED avoids re-polling Circle for something you already have.
 */
export async function markFailed(orderId, errorMessage, retryStatus) {
  const { data, error: fetchError } = await supabase
    .from('bridge_orders')
    .select('claim_attempts')
    .eq('id', orderId)
    .single();

  if (fetchError) throw fetchError;

  const attempts = (data?.claim_attempts ?? 0) + 1;
  const nextStatus = attempts >= config.maxClaimAttempts ? 'FAILED' : retryStatus;

  const { error } = await supabase
    .from('bridge_orders')
    .update({
      status: nextStatus,
      claim_attempts: attempts,
      last_error: String(errorMessage).slice(0, 2000),
      updated_at: new Date().toISOString(),
    })
    .eq('id', orderId);

  if (error) throw error;
}
