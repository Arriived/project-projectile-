import { config } from './config.js';
import {
  getActiveOrders,
  markAttested,
  markClaimSubmitted,
  markClaimed,
  markFailed,
} from './supabaseOrderStore.js';
import { fetchAttestation } from './circleAttestation.js';
import { submitClaim, getRelayerBalance } from './arcRelayerClient.js';

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function processOrder(order) {
  try {
    let current = order;

    if (current.status === 'PENDING_ATTESTATION') {
      const result = await fetchAttestation(current.source_domain, current.source_tx_hash);
      if (result.status !== 'complete') return; // still waiting, re-check next tick

      await markAttested(current.id, result.message, result.attestation);
      current = { ...current, status: 'ATTESTED', message_bytes: result.message, attestation: result.attestation };
    }

    if (current.status === 'ATTESTED') {
      await markClaimSubmitted(current.id);
      const receipt = await submitClaim(current.message_bytes, current.attestation);
      await markClaimed(current.id, receipt.hash);
      console.log(`[relayer] claimed order ${current.id} -- arc tx ${receipt.hash}`);
    }
  } catch (err) {
    console.error(`[relayer] order ${order.id} failed:`, err.message);
    const retryStatus = order.status === 'PENDING_ATTESTATION' ? 'PENDING_ATTESTATION' : 'ATTESTED';
    try {
      await markFailed(order.id, err.message, retryStatus);
    } catch (innerErr) {
      // If even recording the failure fails, log loudly -- this order
      // needs a human to look at it.
      console.error(`[relayer] could not record failure for order ${order.id}:`, innerErr.message);
    }
  }
}

export async function runRelayerLoop() {
  console.log(`[relayer] starting -- poll interval ${config.pollIntervalMs}ms`);

  const balance = await getRelayerBalance();
  console.log(`[relayer] wallet balance: ${balance} (native gas / USDC)`);
  if (parseFloat(balance) < config.minRelayerBalanceUsdc) {
    console.warn(
      `[relayer] WARNING: balance below threshold (${config.minRelayerBalanceUsdc}) -- top up before this runs dry mid-claim`,
    );
  }

  // Single-instance assumption: this loop assumes one relayer process
  // runs at a time. If you ever scale to multiple instances for
  // redundancy, the idempotency guards in supabaseOrderStore reduce
  // double-claim risk but don't eliminate a race window -- add
  // row-level locking (e.g. SELECT ... FOR UPDATE SKIP LOCKED via an
  // RPC function) before doing that.
  for (;;) {
    try {
      const orders = await getActiveOrders();
      for (const order of orders) {
        // eslint-disable-next-line no-await-in-loop
        await processOrder(order);
      }
    } catch (err) {
      console.error('[relayer] loop error:', err.message);
    }
    // eslint-disable-next-line no-await-in-loop
    await sleep(config.pollIntervalMs);
  }
}
