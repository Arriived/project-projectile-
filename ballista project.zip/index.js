import { runRelayerLoop } from './relayerLoop.js';

runRelayerLoop().catch((err) => {
  console.error('[relayer] fatal error, exiting:', err);
  process.exit(1);
});
