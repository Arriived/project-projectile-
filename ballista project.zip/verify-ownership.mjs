import { ethers } from 'ethers';

/**
 * Run this BEFORE and AFTER the ownership transfer.
 *
 * Before: confirms the old EOA is still the owner (sanity check that
 * you're pointed at the right contract before touching anything).
 *
 * After: confirms the Safe is now the owner AND that the old EOA can
 * no longer call an owner-only function -- a successful transferOwnership
 * transaction is not, by itself, proof the old key is actually locked
 * out. This checks the actual behavior, not just the event log.
 *
 * Usage:
 *   node verify-ownership.mjs <before|after>
 */

const RPC_URL = process.env.ARC_RPC_URL;
const CONTRACT_ADDRESS = process.env.CONTRACT_ADDRESS; // ArcLaunchFactory
const OLD_OWNER_ADDRESS = process.env.OLD_OWNER_ADDRESS; // the EOA being retired
const EXPECTED_NEW_OWNER = process.env.SAFE_ADDRESS; // only needed for the "after" check

// Minimal ABI -- adjust `pause` to whatever owner-only function your
// contract actually exposes if it isn't Pausable. The point is calling
// ANY owner-gated function as a static (non-broadcast) call, so this
// costs no gas and changes no state -- it only reads whether the call
// would revert.
const ABI = [
  'function owner() view returns (address)',
  'function pause() external',
];

// Arc's public RPC breaks ethers' default batching -- same fix used
// everywhere else in this project.
const provider = new ethers.JsonRpcProvider(RPC_URL, undefined, { batchMaxCount: 1 });
const contract = new ethers.Contract(CONTRACT_ADDRESS, ABI, provider);

async function main() {
  const mode = process.argv[2];
  if (!['before', 'after'].includes(mode)) {
    throw new Error('Usage: node verify-ownership.mjs <before|after>');
  }

  const currentOwner = await contract.owner();
  console.log(`Current owner(): ${currentOwner}`);

  if (mode === 'before') {
    if (currentOwner.toLowerCase() !== OLD_OWNER_ADDRESS.toLowerCase()) {
      throw new Error(
        `Owner is not who you expected before the transfer. Expected ${OLD_OWNER_ADDRESS}, got ${currentOwner}. Stop and figure out why before proceeding.`,
      );
    }
    console.log('OK -- old EOA confirmed as current owner. Safe to proceed with transferOwnership.');
    return;
  }

  // mode === 'after'
  if (currentOwner.toLowerCase() !== EXPECTED_NEW_OWNER.toLowerCase()) {
    throw new Error(
      `Owner is NOT the Safe. Expected ${EXPECTED_NEW_OWNER}, got ${currentOwner}. ` +
        `If your contract uses Ownable2Step, this likely means acceptOwnership() ` +
        `hasn't been called from the Safe yet -- the transfer is still pending, ` +
        `not complete.`,
    );
  }
  console.log('OK -- Safe confirmed as new owner().');

  // Confirm the old EOA is actually locked out, not just theoretically.
  try {
    await contract.pause.staticCall({ from: OLD_OWNER_ADDRESS });
    throw new Error(
      'DANGER: the old EOA was able to statically call an owner-only function ' +
        'without reverting. This means it may still have effective control. ' +
        'Do not treat the migration as complete until this is investigated.',
    );
  } catch (err) {
    if (err.message.startsWith('DANGER')) throw err;
    console.log('OK -- old EOA correctly reverts on an owner-only call. It no longer has control.');
  }
}

main().catch((err) => {
  console.error(err.message);
  process.exitCode = 1;
});
