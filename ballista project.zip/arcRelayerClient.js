import { ethers } from 'ethers';
import { config } from './config.js';

// Minimal ABI -- this service only ever calls receiveMessage.
const MESSAGE_TRANSMITTER_ABI = [
  'function receiveMessage(bytes message, bytes attestation) external returns (bool success)',
];

// Arc's public RPC aggressively rate-limits concurrent requests and
// silently breaks ethers' default request batching. Keep
// batchMaxCount: 1 -- this project already hit that bug once.
const provider = new ethers.JsonRpcProvider(config.arcRpcUrl, undefined, {
  batchMaxCount: 1,
});

const wallet = new ethers.Wallet(config.relayerPrivateKey, provider);

const messageTransmitter = new ethers.Contract(
  config.messageTransmitterAddress,
  MESSAGE_TRANSMITTER_ABI,
  wallet,
);

export const relayerAddress = wallet.address;

/**
 * Submits the destination-side claim. This is a permissionless call --
 * the mint recipient was already fixed inside the message at burn time
 * on the source chain, so this relayer never touches or redirects user
 * funds. It only pays Arc gas to trigger a mint that was already
 * committed.
 */
export async function submitClaim(messageBytes, attestationBytes) {
  const tx = await messageTransmitter.receiveMessage(messageBytes, attestationBytes);
  const receipt = await tx.wait();
  return receipt;
}

/**
 * Arc's native balance IS USDC (18 decimals internally, per Arc's gas
 * design). If your deployment ever needs the ERC-20 interface balance
 * instead, swap this for a balanceOf() call against the ERC-20 USDC
 * contract -- confirm which one your gas actually draws from before
 * trusting this number for alerting.
 */
export async function getRelayerBalance() {
  const balanceWei = await provider.getBalance(wallet.address);
  return ethers.formatUnits(balanceWei, 18);
}
