# BridgeWithPermit

Cuts the source-chain leg of a cross-chain buy from "approve, then burn"
(2 on-chain transactions, every time) down to "sign a free off-chain
message, then confirm one transaction" -- and unlike a one-time
unlimited approval, this works the same way on a user's very first
bridge, not just their second.

Deploy once per source chain (Base, Ethereum). Pairs with the
`bridge-relayer` service, which handles the Arc-side claim once Circle
attests the message this contract sends.

## What's actually verified here

- **The contract compiles.** Checked with solc 0.8.24 directly.
- **The `depositForBurn` signature is real**, confirmed against Circle's
  own source: github.com/circlefin/evm-cctp-contracts, `TokenMessenger.sol`.
  That source is the base TokenMessenger contract; TokenMessengerV2
  keeps this same signature for its standard-transfer path, which is
  what this wrapper uses. It does **not** cover CCTP V2's fast-transfer
  path (`depositForBurnWithHook`, with extra fee/finality params) --
  that's a different function with a signature I have not verified.
  Standard transfer only for now.
- **The TokenMessengerV2 addresses in `scripts/deploy.js`** are real,
  pulled directly from Circle's official contract-addresses reference
  (developers.circle.com/cctp/references/contract-addresses) on
  2026-08-14.
- **5 tests pass** against the real compiled bytecode on Hardhat's
  local EVM: successful bridge, front-run tolerance, zero-amount
  rejection, expired-deadline rejection, and confirmation that one
  user's signature can't be used by someone else to redirect funds.

## What's explicitly NOT verified / NOT done

- **Arc mainnet is not in Circle's published address list yet** (checked
  2026-08-14). Only Arc Testnet (domain 26) is listed. `deploy.js`
  refuses to run for mainnet until you've re-checked that reference
  page and filled in the real domain/address yourself -- it does not
  guess.
- **USDC's contract address on Base/Ethereum is not hardcoded anywhere
  in this project.** `deploy.js` requires it as an env var you supply.
  Getting a token address wrong here isn't a bug that reverts loudly,
  it's funds sent into the wrong contract -- verify it yourself against
  Circle's USDC address reference before deploying.
- **Fast Transfer is not implemented.** This uses Standard Transfer,
  which is slower (minutes, depending on source-chain finality) but is
  the path I could actually verify. Worth adding once you've confirmed
  the V2 fast-transfer function signature directly.
- **No third-party security review.** This is a small, narrow contract
  (no owner, no pausability, no persistent balance, ~2KB runtime), but
  "narrow" isn't the same as "audited." Treat it the same way the rest
  of this project treats new contract code before mainnet.

## A note on how the tests were run

`npx hardhat test` normally downloads the Solidity compiler from
`binaries.soliditylang.org` the first time you run it. That download
was blocked in the sandbox this was built in, so the artifacts here
were compiled directly with the `solc` npm package (which *is*
reachable via the npm registry) and written straight into Hardhat's
artifact format, then run with `hardhat test --no-compile`. This is a
sandbox-only workaround, not a real limitation -- on your own machine
with normal internet access, delete the `artifacts/` folder and
`npx hardhat test` will download the compiler and work exactly as
usual. Just flagging it so it isn't confusing.

## Setup

```
npm install
npx hardhat test        # confirms everything still works in your environment

USDC_ADDRESS=0x...       \  # canonical USDC on the source chain -- verify yourself
SOURCE_CHAIN=baseSepolia \  # or: base, ethereum, ethereumSepolia
CCTP_ENV=testnet         \  # or: mainnet (blocked until Arc is confirmed live)
npx hardhat run scripts/deploy.js --network baseSepolia
```

You'll need a `--network` entry in `hardhat.config.js` for whichever
chain you're deploying to (RPC URL + deployer key) -- not included
here since that's specific to how you manage secrets.

## Files

```
contracts/
  BridgeWithPermit.sol       the actual contract
  test/
    MockUSDCPermit.sol       real EIP-2612 token (OpenZeppelin) for tests
    MockTokenMessenger.sol   records calls instead of real cross-chain messaging
test/
  BridgeWithPermit.test.js
scripts/
  deploy.js
```
