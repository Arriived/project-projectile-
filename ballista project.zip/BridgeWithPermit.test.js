const { expect } = require('chai');
const { ethers } = require('hardhat');

const DESTINATION_DOMAIN = 26; // Arc Testnet, per Circle's published domain list
const ONE_USDC = 1_000_000n; // 6 decimals

async function signPermit(usdc, owner, spender, value, deadline) {
  const [name, version, chainId, verifyingContract] = await Promise.all([
    usdc.name(),
    '1',
    ethers.provider.getNetwork().then((n) => n.chainId),
    usdc.getAddress(),
  ]);

  const nonce = await usdc.nonces(owner.address);

  const domain = { name, version, chainId, verifyingContract };
  const types = {
    Permit: [
      { name: 'owner', type: 'address' },
      { name: 'spender', type: 'address' },
      { name: 'value', type: 'uint256' },
      { name: 'nonce', type: 'uint256' },
      { name: 'deadline', type: 'uint256' },
    ],
  };
  const message = { owner: owner.address, spender, value, nonce, deadline };

  const signature = await owner.signTypedData(domain, types, message);
  return ethers.Signature.from(signature);
}

function addressToBytes32(addr) {
  return ethers.zeroPadValue(addr, 32);
}

describe('BridgeWithPermit', function () {
  async function deployFixture() {
    const [user, other] = await ethers.getSigners();

    const USDC = await ethers.getContractFactory('MockUSDCPermit');
    const usdc = await USDC.deploy();

    const Messenger = await ethers.getContractFactory('MockTokenMessenger');
    const messenger = await Messenger.deploy();

    const Bridge = await ethers.getContractFactory('BridgeWithPermit');
    const bridge = await Bridge.deploy(
      await usdc.getAddress(),
      await messenger.getAddress(),
      DESTINATION_DOMAIN,
    );

    await usdc.mint(user.address, 100n * ONE_USDC);

    return { user, other, usdc, messenger, bridge };
  }

  it('bridges via a single permit signature with no prior approve() call', async function () {
    const { user, usdc, messenger, bridge } = await deployFixture();

    const amount = 10n * ONE_USDC;
    const deadline = Math.floor(Date.now() / 1000) + 3600;
    const bridgeAddress = await bridge.getAddress();
    const usdcAddress = await usdc.getAddress();

    // Confirm there is genuinely no prior allowance -- this is the thing
    // the whole feature is about avoiding.
    expect(await usdc.allowance(user.address, bridgeAddress)).to.equal(0n);

    const sig = await signPermit(usdc, user, bridgeAddress, amount, deadline);

    const balanceBefore = await usdc.balanceOf(user.address);

    const tx = await bridge
      .connect(user)
      .bridgeWithPermit(amount, deadline, sig.v, sig.r, sig.s);
    const receipt = await tx.wait();

    // Funds actually moved.
    expect(await usdc.balanceOf(user.address)).to.equal(balanceBefore - amount);

    // TokenMessenger was called with exactly the right parameters --
    // in particular, the recipient is the user's own address, not
    // anything the caller could have substituted.
    expect(await messenger.callCount()).to.equal(1n);
    const call = await messenger.calls(0);
    expect(call.amount).to.equal(amount);
    expect(call.destinationDomain).to.equal(DESTINATION_DOMAIN);
    expect(call.mintRecipient).to.equal(addressToBytes32(user.address));
    expect(call.burnToken).to.equal(usdcAddress);

    // Event emitted with the right data.
    await expect(tx)
      .to.emit(bridge, 'BridgeInitiated')
      .withArgs(user.address, amount, 1n);

    // Nothing left behind in the wrapper contract.
    expect(await usdc.balanceOf(bridgeAddress)).to.equal(0n);
  });

  it('tolerates the permit being front-run with the same signature', async function () {
    const { user, usdc, bridge } = await deployFixture();

    const amount = 5n * ONE_USDC;
    const deadline = Math.floor(Date.now() / 1000) + 3600;
    const bridgeAddress = await bridge.getAddress();

    const sig = await signPermit(usdc, user, bridgeAddress, amount, deadline);

    // Simulate someone else submitting the same public signature first --
    // the allowance ends up in the same place regardless of who calls it.
    await usdc.permit(user.address, bridgeAddress, amount, deadline, sig.v, sig.r, sig.s);
    expect(await usdc.allowance(user.address, bridgeAddress)).to.equal(amount);

    // The user's own call should still succeed -- it must not try to
    // consume the now-already-used signature a second time.
    await expect(
      bridge.connect(user).bridgeWithPermit(amount, deadline, sig.v, sig.r, sig.s),
    ).to.not.be.reverted;
  });

  it('rejects a zero amount', async function () {
    const { user, usdc, bridge } = await deployFixture();
    const deadline = Math.floor(Date.now() / 1000) + 3600;
    const bridgeAddress = await bridge.getAddress();

    const sig = await signPermit(usdc, user, bridgeAddress, 0n, deadline);

    await expect(
      bridge.connect(user).bridgeWithPermit(0n, deadline, sig.v, sig.r, sig.s),
    ).to.be.revertedWith('amount must be nonzero');
  });

  it('rejects an expired permit deadline', async function () {
    const { user, usdc, bridge } = await deployFixture();
    const amount = 1n * ONE_USDC;
    const deadline = Math.floor(Date.now() / 1000) - 1; // already expired
    const bridgeAddress = await bridge.getAddress();

    const sig = await signPermit(usdc, user, bridgeAddress, amount, deadline);

    await expect(
      bridge.connect(user).bridgeWithPermit(amount, deadline, sig.v, sig.r, sig.s),
    ).to.be.reverted;
  });

  it('cannot be used to bridge funds the caller does not own', async function () {
    const { user, other, usdc, bridge } = await deployFixture();
    const amount = 1n * ONE_USDC;
    const deadline = Math.floor(Date.now() / 1000) + 3600;
    const bridgeAddress = await bridge.getAddress();

    // `other` has no USDC and never signed anything -- `user`'s valid
    // signature must not be usable by `other` to move `user`'s funds to
    // a recipient `other` controls. The recipient is always msg.sender,
    // so `other` calling this only ever bridges `other`'s own (zero)
    // balance, not user's.
    const sig = await signPermit(usdc, user, bridgeAddress, amount, deadline);

    await expect(
      bridge.connect(other).bridgeWithPermit(amount, deadline, sig.v, sig.r, sig.s),
    ).to.be.reverted; // other has no USDC and the signature was scoped to `user` as owner, not `other`
  });
});
