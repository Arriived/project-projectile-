-- Tracks a single cross-chain "bridge then buy" order.
--
-- Lifecycle:
--   PENDING_ATTESTATION  -- burn tx submitted on source chain, waiting on Circle
--   ATTESTED             -- Circle has signed the message, ready to claim on Arc
--   CLAIM_SUBMITTED       -- relayer has sent the receiveMessage tx on Arc
--   CLAIMED               -- USDC has landed in the user's own Arc wallet
--   FAILED                -- gave up after MAX_CLAIM_ATTEMPTS
--
-- Note: this table only tracks the bridge leg. The final buy() call is
-- signed and submitted by the user's own wallet once funds land -- the
-- relayer never executes it and never custodies user funds.

create table if not exists bridge_orders (
  id uuid primary key default gen_random_uuid(),

  user_address text not null,               -- same address on source chain and Arc (EVM)
  source_chain text not null,               -- 'base' | 'ethereum'
  source_domain integer not null,           -- CCTP domain id of source chain
  destination_domain integer not null,      -- Arc's CCTP domain id

  source_tx_hash text not null unique,      -- the depositForBurn tx on the source chain
  message_bytes text,                        -- raw CCTP message, populated once attested
  attestation text,                          -- Circle's signed attestation, populated once attested

  amount_usdc bigint not null,              -- raw 6-decimal integer -- same convention as your other tables
  target_token text not null,               -- Arc token address the user intends to buy once funds land
  recipient_address text not null,          -- must equal user_address for V1, no third-party recipients

  status text not null default 'PENDING_ATTESTATION',
  arc_claim_tx_hash text,
  claim_attempts integer not null default 0,
  last_error text,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint bridge_orders_status_check check (
    status in ('PENDING_ATTESTATION', 'ATTESTED', 'CLAIM_SUBMITTED', 'CLAIMED', 'FAILED')
  ),
  constraint bridge_orders_recipient_check check (
    recipient_address = user_address
  )
);

create index if not exists bridge_orders_status_idx on bridge_orders (status);
create index if not exists bridge_orders_user_idx on bridge_orders (user_address);

alter table bridge_orders enable row level security;

-- PLACEHOLDER POLICIES.
-- These assume wallet address is available as a JWT claim, matching
-- whatever pattern your existing three tables already use for RLS.
-- I haven't seen that config, so treat this as a stand-in to align with
-- your real auth binding before relying on it -- get this wrong and
-- either nobody can see their own orders, or everyone can see everyone's.

create policy "users can view their own bridge orders"
  on bridge_orders for select
  using (auth.jwt() ->> 'wallet_address' = user_address);

create policy "users can insert their own bridge orders"
  on bridge_orders for insert
  with check (auth.jwt() ->> 'wallet_address' = user_address);

-- Deliberately no update/delete policy for anon/authenticated roles.
-- Only the relayer service, using the Supabase service-role key (which
-- bypasses RLS), should ever transition an order's status. If the
-- frontend can update its own status column, a user could mark their
-- own order CLAIMED without funds ever landing.
