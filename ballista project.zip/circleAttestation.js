import { config } from './config.js';

/**
 * Looks up the CCTP v2 message + attestation for a given source-chain
 * burn transaction.
 *
 * Endpoint shape follows Circle's documented v2 attestation retrieval
 * pattern: GET /v2/messages/{sourceDomain}?transactionHash=...
 *
 * CONFIRM this against Circle's current developer docs before trusting
 * it in production -- endpoint paths and response shapes have changed
 * between CCTP versions before, and this service moves real funds.
 *
 * Returns:
 *   { status: 'pending' }
 *   { status: 'complete', message: '0x...', attestation: '0x...' }
 */
export async function fetchAttestation(sourceDomain, sourceTxHash) {
  const url = `${config.circleIrisBaseUrl}/v2/messages/${sourceDomain}?transactionHash=${sourceTxHash}`;

  const res = await fetch(url);

  if (res.status === 404) {
    // Not indexed by Circle yet -- this is normal in the first
    // seconds after a burn, treat as still pending, not an error.
    return { status: 'pending' };
  }

  if (!res.ok) {
    throw new Error(`Circle attestation lookup failed: ${res.status} ${await res.text()}`);
  }

  const body = await res.json();
  const message = body?.messages?.[0];

  if (!message || message.status !== 'complete') {
    return { status: 'pending' };
  }

  return {
    status: 'complete',
    message: message.message,
    attestation: message.attestation,
  };
}
