// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @dev Only the USDC functions this contract actually calls.
interface IUSDCPermit {
    function permit(
        address owner,
        address spender,
        uint256 value,
        uint256 deadline,
        uint8 v,
        bytes32 r,
        bytes32 s
    ) external;

    function transferFrom(address from, address to, uint256 amount) external returns (bool);
    function approve(address spender, uint256 amount) external returns (bool);
    function allowance(address owner, address spender) external view returns (uint256);
}

/// @dev Matches Circle's deployed TokenMessenger.depositForBurn signature,
/// confirmed against the source at:
/// github.com/circlefin/evm-cctp-contracts/blob/master/src/TokenMessenger.sol
///
/// NOTE: that source is the base TokenMessenger contract. TokenMessengerV2
/// deployments keep this same basic depositForBurn signature for the
/// standard-transfer path (this is what this wrapper uses). V2's
/// *fast*-transfer / hooks path uses a different function
/// (depositForBurnWithHook, with additional maxFee / minFinalityThreshold
/// params) that is NOT verified here and NOT what this contract calls --
/// confirm that signature separately before adding fast-transfer support.
interface ITokenMessengerV2 {
    function depositForBurn(
        uint256 amount,
        uint32 destinationDomain,
        bytes32 mintRecipient,
        address burnToken
    ) external returns (uint64 nonce);
}

/// @title BridgeWithPermit
/// @notice Bridges USDC to Arc in a single on-chain transaction, authorized
/// by an off-chain EIP-2612 permit signature instead of a separate
/// approve() transaction. Cuts the source-chain leg of a cross-chain buy
/// from "approve, then burn" (2 on-chain transactions) down to "sign a
/// free off-chain message, then confirm one transaction" -- and unlike a
/// one-time unlimited approval, this works identically on a user's very
/// first bridge, not just their second.
///
/// @dev Deliberately narrow, deliberately not owned or pausable:
/// - usdc, tokenMessenger, and destinationDomain are all immutable --
///   nothing about this contract can be reconfigured after deployment,
///   so there is no admin key here that could redirect funds.
/// - The mint recipient is always msg.sender's own address. There is no
///   parameter that lets a caller send someone else's bridged funds to a
///   third-party address.
/// - This contract never holds a standing balance between transactions.
///   Every call pulls exactly `amount` in and forwards exactly `amount`
///   out, atomically. There is nothing sitting here to drain between
///   transactions.
/// - One deployment per source chain (e.g. one on Base, one on
///   Ethereum) -- destinationDomain is fixed at deployment to Arc's
///   domain, this contract has exactly one job.
contract BridgeWithPermit {
    IUSDCPermit public immutable usdc;
    ITokenMessengerV2 public immutable tokenMessenger;
    uint32 public immutable destinationDomain;

    // Minimal reentrancy guard -- kept self-contained so this file has no
    // external dependency to audit alongside it.
    uint256 private constant NOT_ENTERED = 1;
    uint256 private constant ENTERED = 2;
    uint256 private locked = NOT_ENTERED;

    modifier nonReentrant() {
        require(locked == NOT_ENTERED, "reentrant call");
        locked = ENTERED;
        _;
        locked = NOT_ENTERED;
    }

    event BridgeInitiated(address indexed user, uint256 amount, uint64 nonce);

    constructor(address _usdc, address _tokenMessenger, uint32 _destinationDomain) {
        require(_usdc != address(0), "usdc not set");
        require(_tokenMessenger != address(0), "token messenger not set");

        usdc = IUSDCPermit(_usdc);
        tokenMessenger = ITokenMessengerV2(_tokenMessenger);
        destinationDomain = _destinationDomain;

        // This contract's own standing approval to TokenMessenger, set
        // once at deployment. This is not a user's allowance and there is
        // never a balance here for it to expose -- every transaction
        // pulls in and burns the same amount in the same call.
        usdc.approve(_tokenMessenger, type(uint256).max);
    }

    /// @notice Bridges `amount` of the caller's own USDC to Arc.
    /// @dev If an equivalent allowance already exists (e.g. the permit
    /// signature was already consumed by someone resubmitting it from the
    /// public mempool ahead of this call), the redundant permit() call is
    /// skipped rather than left to revert -- the outcome is identical
    /// either way, so there's no reason to fail the transaction over it.
    function bridgeWithPermit(
        uint256 amount,
        uint256 deadline,
        uint8 v,
        bytes32 r,
        bytes32 s
    ) external nonReentrant returns (uint64 nonce) {
        require(amount > 0, "amount must be nonzero");

        if (usdc.allowance(msg.sender, address(this)) < amount) {
            usdc.permit(msg.sender, address(this), amount, deadline, v, r, s);
        }

        require(usdc.transferFrom(msg.sender, address(this), amount), "USDC pull failed");

        bytes32 mintRecipient = bytes32(uint256(uint160(msg.sender)));

        nonce = tokenMessenger.depositForBurn(amount, destinationDomain, mintRecipient, address(usdc));

        emit BridgeInitiated(msg.sender, amount, nonce);
    }
}
