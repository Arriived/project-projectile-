# Ballista

A memecoin launchpad native to Arc (Circle's stablecoin L1, USDC as native gas).
Bonding-curve launches that graduate to a DEX pool, with cross-chain USDC buy-in
so a user on Base/Ethereum/Solana can buy an Arc-native token without manually
bridging first.

**Positioning:** what Pons V2 is to Robinhood Chain, but for Arc. Same shape of
product, different chain, plus cross-chain USDC on-ramping as the differentiator.

---

## Timeline — this is the constraint that governs everything

- **Arc mainnet: September 16, 2026.** Confirmed, external, immovable.
- **Ballista must be launch-ready by ~September 9** — a week early, deliberately.
  That week is buffer for problems found late, not spare time to add features.
- Build and test on **Arc Testnet**. Mainnet is a config flip on launch day
  (chain ID, RPC, contract addresses), not a rebuild.

## Scope for mainnet launch

**IN:**
- Launchpad: create token → bonding curve trading → graduation to DEX
- CCTP bridging so users can buy with USDC from other chains
- Automatic buys (bridge lands → buy executes with minimal user friction)
- Frontend for the above

**OUT — do not build these before mainnet:**
- The trading terminal. Explicitly cut from launch scope. Post-launch.
- Buybacks, fee escrow, vesting
- Anything not on the path to "a user can launch a token and another user can
  buy it, including from another chain"

If a proposed feature isn't required for that sentence to be true, it's post-launch.
Scope creep is the main risk to the date. Push back on it, including when the
push comes from me.

---

## Current state

### Contract — `Ballista.sol` (was `ArcLaunchFactory`)
Compiled, 37 tests passing locally. **Not yet deployed anywhere.** The previous
version (`ArcLaunchFactory`) is live on Arc Testnet at
`0x63C4c5b7D7add4dbE9Bf8f155711dd00F566Ec57`, verified on Blockscout.

Recent changes, all tested:
- Renamed to `Ballista`
- Graduation threshold 67,000 USDC (was 69,000)
- Symbol lock is time-limited (5 min default) rather than permanent
- `caseSensitiveSymbols` toggle — starts lenient (true), tighten later
- Block-0 trading restriction (`creationBlock`, trading opens next block)
- **Partial-fill + clamp** on `buy()` and `sell()` — no longer reverts when the
  request exceeds remaining supply; fills what's available, never pulls the excess
- **Decoupled graduation** — `ACTIVE → GRADUATION_READY → GRADUATED` state enum,
  one-way. A failing router can't unwind the trade that triggered it. `graduate()`
  is permissionless and retryable.
- **Economics pinning** — `createToken()` takes `expectedEconomicsHash`; reverts if
  fees/threshold/symbol policy changed since the creator saw the terms
- `quoteBuy()` / `quoteSell()` views sharing the exact same math as execution

### Other components (built, never run against real infrastructure)
- `BridgeWithPermit.sol` — permit-based CCTP burn, one tx instead of approve+burn.
  5 tests passing. Deploy one per source chain.
- `bridge-relayer/` — Node service: watches Circle attestation, submits Arc-side claim.
- `verify-ownership.mjs` — checks multisig ownership transfer actually took effect.

---

## Open items, roughly in priority order

1. **Multisig migration.** Contract owner is still a single EOA. Safe is confirmed
   live on Arc Testnet. 2-of-3, keys must be *independently generated* — not one
   seed copied three ways. Contract uses plain `Ownable`, NOT `Ownable2Step`, so
   `transferOwnership()` is immediate and irreversible. Verify the address twice.
2. **Run the original 19-test suite** against the new `Ballista.sol`. It exists in
   this repo but has never been run against the rewritten contract — this is the
   biggest untested gap.
3. Deploy `Ballista.sol` to Arc Testnet, verify on Blockscout.
4. Apply the `ArcLaunchFactory` → `Ballista` rename across remaining files.
5. End-to-end CCTP test: Base Sepolia → Arc Testnet, including failure paths.
6. Frontend.
7. P1 (only if the date is safe): decaying snipe tax, creator fee share.

---

## Hard-won constraints — these have already caused real bugs

- **Arc RPC requires `batchMaxCount: 1`** in every ethers.js provider config.
  Default batching silently breaks against Arc's public RPC.
- **Never re-derive the bonding curve math.** Use `_quoteBuy` / `_quoteSell`.
  External LLMs have re-derived it incorrectly more than once.
- **USDC is 6 decimals** in all contract amounts. Arc also exposes USDC as native
  gas with 18 decimals internally — these are not interchangeable. Confirm which
  one you're touching before assuming.
- **Graduation threshold cannot exceed ~87,912 USDC.** That's the computed maximum
  `realUsdcReserves` can ever reach at full curve depletion. Set it higher and a
  sold-out token can never graduate — it just sits there, permanently stuck. 67,000
  leaves deliberate margin.
- **Fees are read per-token from `curves()`**, snapshotted at creation. Never assume
  the global default applies to an existing token.
- **Never put raw private keys in browser storage.** Rejected permanently, any framing.
- The relayer never custodies user funds — it only pays gas to trigger a mint whose
  recipient was fixed at burn time on the source chain. Keep it that way. No session
  keys, no relayer-signs-buy-on-behalf-of-user.

## Verification rules

- **Always verify Arc / Circle / CCTP / Bridge Kit claims against the official docs**
  (`developers.circle.com`, `docs.arc.io`) rather than from memory or training data.
  Contract addresses and domain IDs especially — a wrong address is unrecoverable
  fund loss, not a revert.
- Arc **mainnet** is not yet in Circle's published CCTP address list. Testnet is
  (domain 26). Re-check before any mainnet config.
- Uniswap is confirmed on Arc at launch. **Version is not confirmed** — reporting
  says v4, but not from a primary source. Don't build V4-specific code until
  confirmed; V3 and V4 aren't interchangeable.

## Working style

- One feature at a time: build it, then genuinely try to break it, then move on.
  Adversarial tests, not just happy-path confirmation.
- Prefer restructuring code over enabling a compiler flag to work around a limit
  (e.g. stack-too-deep → extract a function, don't just turn on `viaIR`).
- I bring code back from Gemini/ChatGPT for auditing. Assume it may contain
  invented ABI params, wrong decimals, or fabricated functions. Verify against
  actual source before trusting it.
- Be direct. If an idea is bad, say so and say why. Don't soften it.

## Stack

Solidity 0.8.24 · Hardhat · Foundry (invariant fuzzing) · Slither · SolidityScan
Node.js · Supabase (Postgres + RLS) · plain HTML/CSS/JS frontend (no React, no build step)
Arc Testnet · Circle CCTP V2 · Safe multisig · Blockscout
