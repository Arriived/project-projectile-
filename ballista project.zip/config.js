import 'dotenv/config';

function required(name) {
  const value = process.env[name];
  if (!value) {
    throw new Error(`Missing required env var: ${name} (see .env.example)`);
  }
  return value;
}

function requiredInt(name) {
  const raw = required(name);
  const value = parseInt(raw, 10);
  if (Number.isNaN(value)) {
    throw new Error(`Env var ${name} must be an integer, got "${raw}"`);
  }
  return value;
}

export const config = {
  supabaseUrl: required('SUPABASE_URL'),
  supabaseServiceKey: required('SUPABASE_SERVICE_ROLE_KEY'),

  arcRpcUrl: required('ARC_RPC_URL'),
  relayerPrivateKey: required('RELAYER_PRIVATE_KEY'),
  messageTransmitterAddress: required('ARC_MESSAGE_TRANSMITTER_V2_ADDRESS'),

  // Deliberately no default here. Confirm the current value against
  // Circle's live EVM contracts reference before deploying -- don't
  // carry forward a testnet value without re-checking it for mainnet.
  arcDestinationDomain: requiredInt('ARC_DESTINATION_DOMAIN'),

  circleIrisBaseUrl: process.env.CIRCLE_IRIS_BASE_URL || 'https://iris-api.circle.com',

  pollIntervalMs: parseInt(process.env.POLL_INTERVAL_MS || '15000', 10),
  maxClaimAttempts: parseInt(process.env.MAX_CLAIM_ATTEMPTS || '5', 10),
  minRelayerBalanceUsdc: parseFloat(process.env.MIN_RELAYER_BALANCE_USDC || '5'),

  sourceChains: {
    base: { domain: requiredInt('BASE_CCTP_DOMAIN') },
    ethereum: { domain: requiredInt('ETHEREUM_CCTP_DOMAIN') },
  },
};
