const hre = require('hardhat');

// Verified against Circle's official contract-addresses reference
// (developers.circle.com/cctp/references/contract-addresses) on
// 2026-08-14. TokenMessengerV2 is deployed at the same address on
// every EVM chain it supports (CREATE2), which is why mainnet and
// testnet each only need one address, not one per chain.
//
// Arc mainnet is NOT in Circle's published list yet as of this date --
// only Arc Testnet (domain 26). Do not deploy to Arc mainnet, and do
// not treat ARC_DESTINATION_DOMAIN_MAINNET below as real, until you've
// re-checked that reference page yourself and it actually lists Arc.
const TOKEN_MESSENGER_V2 = {
  mainnet: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
  testnet: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
};

const SOURCE_CHAIN_DOMAINS = {
  ethereum: 0,
  ethereumSepolia: 0,
  base: 6,
  baseSepolia: 6,
};

const ARC_DESTINATION_DOMAIN = {
  testnet: 26,
  // mainnet: not yet published by Circle as of 2026-08-14 -- confirm
  // before setting this and deploying anywhere for real.
};

async function main() {
  const networkName = hre.network.name;
  const isTestnet = process.env.CCTP_ENV !== 'mainnet';

  const usdcAddress = process.env.USDC_ADDRESS;
  if (!usdcAddress) {
    throw new Error(
      'Set USDC_ADDRESS to the canonical USDC contract on this source chain. ' +
        'Not defaulted here deliberately -- verify it yourself against Circle\'s ' +
        'USDC contract address reference before deploying, a wrong token address ' +
        'here is not a recoverable mistake.',
    );
  }

  const sourceDomainKey = process.env.SOURCE_CHAIN; // e.g. "base" or "ethereum"
  if (!sourceDomainKey || !(sourceDomainKey in SOURCE_CHAIN_DOMAINS)) {
    throw new Error(
      `Set SOURCE_CHAIN to one of: ${Object.keys(SOURCE_CHAIN_DOMAINS).join(', ')}`,
    );
  }

  const tokenMessengerAddress = isTestnet ? TOKEN_MESSENGER_V2.testnet : TOKEN_MESSENGER_V2.mainnet;

  const destinationDomain = isTestnet
    ? ARC_DESTINATION_DOMAIN.testnet
    : ARC_DESTINATION_DOMAIN.mainnet;

  if (destinationDomain === undefined) {
    throw new Error(
      'Arc mainnet CCTP domain is not confirmed in this script. Re-check ' +
        "Circle's contract-addresses reference for Arc mainnet, add it to " +
        'ARC_DESTINATION_DOMAIN.mainnet above, and only then deploy for real.',
    );
  }

  console.log(`Deploying BridgeWithPermit to ${networkName} (${isTestnet ? 'testnet' : 'mainnet'} CCTP config)`);
  console.log(`  usdc:               ${usdcAddress}`);
  console.log(`  tokenMessenger:     ${tokenMessengerAddress}`);
  console.log(`  destinationDomain:  ${destinationDomain} (Arc)`);

  const Bridge = await hre.ethers.getContractFactory('BridgeWithPermit');
  const bridge = await Bridge.deploy(usdcAddress, tokenMessengerAddress, destinationDomain);
  await bridge.waitForDeployment();

  console.log(`\nBridgeWithPermit deployed: ${await bridge.getAddress()}`);
  console.log('Verify this on the block explorer before pointing any frontend at it.');
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
