# Ballista Bridge Relayer

Backend worker for the cross-chain "pay with USDC from another chain" buy
flow. This is additive to the existing Arc-only launchpad -- it does not
touch `ArcLaunchFactory` and it does not gate the Sept 16 mainnet date.

## What this does

1. Frontend (not yet built) writes a row to `bridge_orders` after the
   user's `depositForBurn` tx confirms on the source chain.
2. This service polls Circle's attestation service for that message.
3. Once attested, it submits `receiveMessage(message, attestation)` on
   Arc's `MessageTransmitterV2`, which mints USDC directly to the
   user's own Arc address (the `mintRecipient` was fixed at burn time,
   on the source chain, by the user's own wallet -- this service never
   chooses or redirects a recipient).
4. Order moves to `CLAIMED`. From here the frontend picks it up: user
   switches their wallet back to Arc and signs the actual `buy()` call
   themselves, against the existing, unmodified contract.

## What this deliberately does NOT do

- No new receiving/router contract on Arc. `ArcLaunchFactory` is
  untouched.
- No custody of user funds. The claim call is permissionless; funds
  always land at the address fixed in the original burn message.
- No session keys, no relayer-signs-`buy()`-on-your-behalf pattern --
  consistent with the session-key approach already rejected earlier in
  this project for the trust/custody issues it introduced.
- No Solana support yet. Different address format, different wallet
  stack -- treat as a separate follow-on, not part of this.

## Setup

```
cp .env.example .env
# fill in .env -- see inline comments, several values are marked
# CONFIRM and must not be guessed or copied from testnet blindly
npm install
```

Run the SQL in `sql/001_create_bridge_orders.sql` against Supabase
before starting the service. The RLS policies in that file are
placeholders -- align the `auth.jwt() ->> 'wallet_address'` claim name
with whatever your existing three tables actually use. I haven't seen
that config, so don't take it on faith.

```
npm start
```

## Update

`.env.example` now has real, verified testnet values (Arc Testnet
`MessageTransmitterV2`, domain 26, Base/Ethereum domains) pulled
directly from Circle's official contract-addresses reference on
2026-08-14. Arc mainnet is not in that list yet -- don't fill in a
mainnet value until it is.

On the source-chain side, pair this with `bridge-permit/` --
`BridgeWithPermit.sol` replaces the old approve-then-burn flow with a
single permit-authorized transaction. This service doesn't change
either way; it only cares about the resulting burn tx hash.

## Before this touches mainnet

- [ ] Re-confirm `ARC_MESSAGE_TRANSMITTER_V2_ADDRESS` and
      `ARC_DESTINATION_DOMAIN` against Circle's current EVM contracts
      reference once Arc mainnet is actually published there -- the
      values currently in `.env.example` are testnet only.
- [ ] Re-confirm `BASE_CCTP_DOMAIN` / `ETHEREUM_CCTP_DOMAIN` the same way (low risk of changing, but check).
- [ ] Confirm whether Circle's attestation is minting into the same
      USDC balance `buy()` reads (Arc exposes USDC as both native gas,
      18 decimals internally, and an ERC-20 interface for the same
      asset) -- this project has already had one decimals bug, don't
      let this be the second.
- [ ] Full testnet dry run: Base Sepolia -> Arc Testnet, including
      failure paths (attestation delay, relayer restart mid-flight,
      relayer balance running low).
- [ ] Confirm Circle's CCTP V2 support for Arc *mainnet* (not just
      testnet) is actually live before flipping this on. This is an
      external dependency you don't control -- don't assume it lands
      day-one with Arc mainnet just because testnet works.
- [ ] Align the RLS policy in the SQL migration with your real auth
      binding.
- [ ] If you ever run more than one relayer instance for redundancy,
      add real row-level locking (`SELECT ... FOR UPDATE SKIP LOCKED`
      via an RPC function) -- the current idempotency guards reduce
      double-claim risk for a single instance but don't fully close a
      multi-instance race.

## Files

```
src/
  config.js              env loading, fails fast on missing/invalid values
  circleAttestation.js   polls Circle's Iris API for a message + attestation
  arcRelayerClient.js    submits the claim tx on Arc (ethers v6, batchMaxCount: 1)
  supabaseOrderStore.js  all reads/writes to bridge_orders, service-role key
  relayerLoop.js         the poll loop + per-order state machine
  index.js               entrypoint
sql/
  001_create_bridge_orders.sql
```
